package cn.itcast.user.mapper;

import cn.itcast.user.pojo.User;

public interface UserMapper extends tk.mybatis.mapper.common.Mapper<User>{
}