package cn.itcast.demo.mapper;

import cn.itcast.demo.pojo.User;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author: HuYi.Zhang
 * @create: 2018-06-14 18:01
 **/
public interface UserMapper extends Mapper<User>{
}
