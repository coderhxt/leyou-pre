package cn.itcast.demo.config;

/**
 * @author: HuYi.Zhang
 * @create: 2018-06-14 15:21
 **/
//@Configuration
//@PropertySource("classpath:application.properties")
//@EnableConfigurationProperties(JdbcProperties.class)
public class JdbcConfig {

//    @Value("${jdbc.driverClassName}")
//    private String driverClassName;
//    @Value("${jdbc.url}")
//    private String url;
//    @Value("${jdbc.username}")
//    private String username;
//    @Value("${jdbc.password}")
//    private String password;

//    @Autowired
//    private JdbcProperties jdbcProperties;
//
//    public JdbcConfig(JdbcProperties jdbcProperties){
//        this.jdbcProperties = jdbcProperties;
//    }

//    @Bean
//    @ConfigurationProperties(prefix = "jdbc")
//    public DataSource dataSource() {
//        return new DruidDataSource();
//    }
}
